﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorOOP
{
    public class Logic
    {

        public double Summ(double a, double b)
        {
            return a + b;
        }
        public double Minus(double a, double b)
        {
            return a - b;
        }
        public double Divide(double a, double b)
        {
            return a / b;
        }
        public double Multiply(double a, double b)
        {
            return a * b;
        }

    }
}
